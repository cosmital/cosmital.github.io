clear; close all
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% variables
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
thetas = [0, 30, -60];
% thetas = [0, 30, -60, 60, 85];
K = length(thetas);

M = 10;
N = 500;

sigma_k_square = 1;
sigma_w_square = 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% create matrices
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
thetas = thetas / 180 *pi; %rad
A = power (exp(1i*sin(thetas)), (0:M-1)');

s = sqrt(sigma_k_square/2)*(randn(K,N)+1i*randn(K,N));
w = sqrt(sigma_w_square/2)*(randn(M,N)+1i*randn(M,N));

Y = A*s + w;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% MUSIC
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% get V2
R_est = (Y * Y')/N;

[V, D] = eig(R_est);

[~, pos_V2] = sort(diag(D));
pos_V2 = pos_V2(1:M-K);
V_2 = V(:,pos_V2);

% the thetas for plot
test_thetas = (-pi/1.5:1e-5:pi/1.5); 

% valid position for [-90,90]
valid_locs = 1:length(test_thetas);
valid_locs = valid_locs((test_thetas >= -pi/2) & (test_thetas <= pi/2));

% 1/norm(a'V2)
A_test = power(exp(1i*sin(test_thetas)), (0:M-1)');
norm_test = A_test'*V_2;
norm_test = 1 ./ sum(norm_test.*conj(norm_test),2);

% peaks of 1/norm(a'V2) in [-90,90]
[pks, locs] = findpeaks(norm_test);
pks = pks(ismember(locs, valid_locs));
locs = locs(ismember(locs, valid_locs));

% remove the mini peaks in case there is any
n_peaks = min(K,length(pks));
[pks, locs1] = maxk(pks, n_peaks);
locs = locs(locs1);

% estimation of thetas
theta_est = test_thetas(locs)*180/pi;
disp(theta_est)

% display
plot(test_thetas(valid_locs)*180/pi, norm_test(valid_locs))
hold on
scatter(theta_est,pks)
for i=1:n_peaks
    text(theta_est(i),pks(i),['  ' num2str(theta_est(i)) '^{\circ}'])
end
title('f(\theta)')
xlabel('\theta')
exportgraphics(gcf,'res.png',Resolution=300)
